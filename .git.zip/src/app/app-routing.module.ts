import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MaincontentComponent } from './maincontent/maincontent.component';
import { ChemistryComponent } from './chemistry/chemistry.component';
import { MathComponent } from './math/math.component'


const routes: Routes = [
  { path: '',   redirectTo: '/physics', pathMatch: 'full' },
  { path: "physics", component: MaincontentComponent },
  { path: "chemistry", component: ChemistryComponent },
  { path: "math", component: MathComponent },


  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
