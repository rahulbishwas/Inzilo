import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chemistry',
  templateUrl: './chemistry.component.html',
  styleUrls: ['./chemistry.component.css']
})
export class ChemistryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
