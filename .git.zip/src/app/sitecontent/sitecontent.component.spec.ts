import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SitecontentComponent } from './sitecontent.component';

describe('SitecontentComponent', () => {
  let component: SitecontentComponent;
  let fixture: ComponentFixture<SitecontentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SitecontentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SitecontentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
