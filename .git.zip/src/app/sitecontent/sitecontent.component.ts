import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sitecontent',
  templateUrl: './sitecontent.component.html',
  styleUrls: ['./sitecontent.component.css']
})
export class SitecontentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  submit(){
  alert("Do you want to submit exam")
  }

}
